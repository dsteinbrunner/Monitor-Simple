Simple monitoring of applications and services.
